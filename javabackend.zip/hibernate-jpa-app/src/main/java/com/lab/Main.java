package com.lab;

import com.lab.entity.*;
import jakarta.persistence.*;
import java.util.*;

public class Main {

    private static final EntityManagerFactory emf =
            Persistence.createEntityManagerFactory("h2-pu");

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n===== HIBERNATE JPA CRUD MENU =====");
            System.out.println("1. Create Department");
            System.out.println("2. Create Employee");
            System.out.println("3. Create Project");
            System.out.println("4. List All Departments");
            System.out.println("5. List All Employees");
            System.out.println("6. List All Projects");
            System.out.println("7. Find Employee by ID");
            System.out.println("8. Update Employee Salary");
            System.out.println("9. Assign Employee to Department");
            System.out.println("10. Assign Employee to Project");
            System.out.println("11. Delete Employee");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");

            int choice;
            try {
                choice = Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Enter a number.");
                continue;
            }

            switch (choice) {
                case 1 -> createDepartment(sc);
                case 2 -> createEmployee(sc);
                case 3 -> createProject(sc);
                case 4 -> listAll(Department.class, "Department");
                case 5 -> listAll(Employee.class, "Employee");
                case 6 -> listAll(Project.class, "Project");
                case 7 -> findEmployee(sc);
                case 8 -> updateSalary(sc);
                case 9 -> assignToDepartment(sc);
                case 10 -> assignToProject(sc);
                case 11 -> deleteEmployee(sc);
                case 0 -> {
                    System.out.println("Exiting...");
                    emf.close();
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    // ---- CREATE ----

    private static void createDepartment(Scanner sc) {
        System.out.print("Enter department name: ");
        String name = sc.nextLine();
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Department d = new Department(name);
            em.persist(d);
            em.getTransaction().commit();
            System.out.println("Created: " + d);
        } catch (Exception e) {
            em.getTransaction().rollback();
            System.out.println("Error: " + e.getMessage());
        } finally {
            em.close();
        }
    }

    private static void createEmployee(Scanner sc) {
        System.out.print("Enter employee name: ");
        String name = sc.nextLine();
        System.out.print("Enter salary: ");
        double salary;
        try {
            salary = Double.parseDouble(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid salary.");
            return;
        }
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Employee e = new Employee(name, salary);
            em.persist(e);
            em.getTransaction().commit();
            System.out.println("Created: " + e);
        } catch (Exception e) {
            em.getTransaction().rollback();
            System.out.println("Error: " + e.getMessage());
        } finally {
            em.close();
        }
    }

    private static void createProject(Scanner sc) {
        System.out.print("Enter project title: ");
        String title = sc.nextLine();
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Project p = new Project(title);
            em.persist(p);
            em.getTransaction().commit();
            System.out.println("Created: " + p);
        } catch (Exception e) {
            em.getTransaction().rollback();
            System.out.println("Error: " + e.getMessage());
        } finally {
            em.close();
        }
    }

    // ---- READ ----

    private static void listAll(Class<?> clazz, String label) {
        EntityManager em = emf.createEntityManager();
        try {
            List<?> results = em.createQuery("SELECT e FROM " + clazz.getSimpleName() + " e", clazz).getResultList();
            if (results.isEmpty()) {
                System.out.println("No " + label + "s found.");
            } else {
                System.out.println("--- " + label + "s ---");
                results.forEach(System.out::println);
            }
        } finally {
            em.close();
        }
    }

    private static void findEmployee(Scanner sc) {
        System.out.print("Enter employee ID: ");
        Long id;
        try {
            id = Long.parseLong(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID.");
            return;
        }
        EntityManager em = emf.createEntityManager();
        try {
            Employee e = em.find(Employee.class, id);
            if (e == null) {
                System.out.println("Employee not found.");
            } else {
                System.out.println(e);
                System.out.println("  Department: " + (e.getDepartment() != null ? e.getDepartment().getName() : "none"));
                System.out.println("  Address: " + (e.getAddress() != null ? e.getAddress() : "none"));
                System.out.println("  Projects: " + (e.getProjects().isEmpty() ? "none" : e.getProjects()));
            }
        } finally {
            em.close();
        }
    }

    // ---- UPDATE ----

    private static void updateSalary(Scanner sc) {
        System.out.print("Enter employee ID: ");
        Long id;
        try {
            id = Long.parseLong(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID.");
            return;
        }
        System.out.print("Enter new salary: ");
        double salary;
        try {
            salary = Double.parseDouble(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid salary.");
            return;
        }
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Employee e = em.find(Employee.class, id);
            if (e == null) {
                System.out.println("Employee not found.");
                em.getTransaction().rollback();
            } else {
                e.setSalary(salary);
                em.getTransaction().commit();
                System.out.println("Updated: " + e);
            }
        } catch (Exception ex) {
            em.getTransaction().rollback();
            System.out.println("Error: " + ex.getMessage());
        } finally {
            em.close();
        }
    }

    // ---- ASSIGN ----

    private static void assignToDepartment(Scanner sc) {
        System.out.print("Enter employee ID: ");
        Long empId;
        try {
            empId = Long.parseLong(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID.");
            return;
        }
        System.out.print("Enter department ID: ");
        Long deptId;
        try {
            deptId = Long.parseLong(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID.");
            return;
        }
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Employee emp = em.find(Employee.class, empId);
            Department dept = em.find(Department.class, deptId);
            if (emp == null || dept == null) {
                System.out.println("Employee or Department not found.");
                em.getTransaction().rollback();
            } else {
                dept.addEmployee(emp);
                em.getTransaction().commit();
                System.out.println("Assigned " + emp.getName() + " to " + dept.getName());
            }
        } catch (Exception ex) {
            em.getTransaction().rollback();
            System.out.println("Error: " + ex.getMessage());
        } finally {
            em.close();
        }
    }

    private static void assignToProject(Scanner sc) {
        System.out.print("Enter employee ID: ");
        Long empId;
        try {
            empId = Long.parseLong(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID.");
            return;
        }
        System.out.print("Enter project ID: ");
        Long projId;
        try {
            projId = Long.parseLong(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID.");
            return;
        }
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Employee emp = em.find(Employee.class, empId);
            Project proj = em.find(Project.class, projId);
            if (emp == null || proj == null) {
                System.out.println("Employee or Project not found.");
                em.getTransaction().rollback();
            } else {
                emp.addProject(proj);
                em.getTransaction().commit();
                System.out.println("Assigned " + emp.getName() + " to " + proj.getTitle());
            }
        } catch (Exception ex) {
            em.getTransaction().rollback();
            System.out.println("Error: " + ex.getMessage());
        } finally {
            em.close();
        }
    }

    // ---- DELETE ----

    private static void deleteEmployee(Scanner sc) {
        System.out.print("Enter employee ID to delete: ");
        Long id;
        try {
            id = Long.parseLong(sc.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Invalid ID.");
            return;
        }
        EntityManager em = emf.createEntityManager();
        try {
            em.getTransaction().begin();
            Employee e = em.find(Employee.class, id);
            if (e == null) {
                System.out.println("Employee not found.");
                em.getTransaction().rollback();
            } else {
                Department dept = e.getDepartment();
                if (dept != null) {
                    dept.getEmployees().remove(e);
                }
                em.remove(e);
                em.getTransaction().commit();
                System.out.println("Deleted employee ID " + id);
            }
        } catch (Exception ex) {
            em.getTransaction().rollback();
            System.out.println("Error: " + ex.getMessage());
        } finally {
            em.close();
        }
    }
}
