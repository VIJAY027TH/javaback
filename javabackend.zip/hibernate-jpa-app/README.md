# 2. Hibernate JPA App (Console CRUD)

Interactive console menu for Employee, Department & Project CRUD using Hibernate + JPA.

## 🚀 How to Run
```bash
mvn compile
mvn org.codehaus.mojo:exec-maven-plugin:3.2.0:java "-Dexec.mainClass=com.lab.Main"
```
*(Or open `src/main/java/com/lab/Main.java` in your IDE and click **Run ▶**)*

## 📋 How to Test
Terminal-la menu appear aagum:
- `1` = Create Department
- `2` = Create Employee
- `5` = List All Employees
- `0` = Exit

*(Uses H2 in-memory DB by default — no database setup needed).*
