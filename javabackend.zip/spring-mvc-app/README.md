# 3. Spring MVC App (Thymeleaf UI)

Classic Spring MVC with HTML web pages using Thymeleaf (In-memory data).

## 🚀 How to Run
```bash
mvn spring-boot:run
```

## 🌐 How to Test
- Open: **http://localhost:8080/employees**
- Web table-la Add, Edit, Delete employees test pannalam.

## 🛑 How to Stop
Press `Ctrl + C`
