package com.lab.controller;

import com.lab.model.Employee;
import jakarta.annotation.PostConstruct;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

@Controller
@RequestMapping("/employees")
public class EmployeeController {

    private final List<Employee> employees = new ArrayList<>();
    private final AtomicLong counter = new AtomicLong();

    @PostConstruct
    public void init() {
        employees.add(new Employee(counter.incrementAndGet(), "Alice", "Engineering", 75000));
        employees.add(new Employee(counter.incrementAndGet(), "Bob", "Marketing", 68000));
    }

    @GetMapping
    public String listEmployees(Model model) {
        model.addAttribute("employees", employees);
        return "index";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("employee", new Employee());
        return "add-employee";
    }

    @PostMapping("/add")
    public String addEmployee(@ModelAttribute Employee employee) {
        employee.setId(counter.incrementAndGet());
        employees.add(employee);
        return "redirect:/employees";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Employee emp = employees.stream()
                .filter(e -> e.getId().equals(id))
                .findFirst().orElse(null);
        model.addAttribute("employee", emp);
        return "edit-employee";
    }

    @PostMapping("/edit/{id}")
    public String updateEmployee(@PathVariable Long id, @ModelAttribute Employee updated) {
        employees.stream()
                .filter(e -> e.getId().equals(id))
                .findFirst()
                .ifPresent(emp -> {
                    emp.setName(updated.getName());
                    emp.setDepartment(updated.getDepartment());
                    emp.setSalary(updated.getSalary());
                });
        return "redirect:/employees";
    }

    @GetMapping("/delete/{id}")
    public String deleteEmployee(@PathVariable Long id) {
        employees.removeIf(e -> e.getId().equals(id));
        return "redirect:/employees";
    }
}
