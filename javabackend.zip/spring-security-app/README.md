# 6. Spring Security App (Role-Based Login)

Form login with ADMIN & USER roles using Spring Security + BCrypt.

## 🚀 How to Run
```bash
mvn spring-boot:run
```

## 🌐 How to Test
Open: **http://localhost:8080/**

Built-in Demo Accounts:
- **Admin**: `admin` / `admin123` (Can access `/admin/dashboard`)
- **User**: `user` / `user123` (Can access `/user/dashboard`)
- **Register**: **http://localhost:8080/register** (Create your own account)

## 🛑 How to Stop
Press `Ctrl + C`
