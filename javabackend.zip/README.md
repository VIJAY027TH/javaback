# Java Backend Lab — MC23CA409

Contains 10 Java & Spring Boot practical programs.

---

## 1️⃣ System Requirements (Enna Theva?)

Only 2 tools are required:
1. **JDK 17 or higher** *(Java 8 or 11 will not work)*
2. **Apache Maven 3.8+**

---

## 2️⃣ How to Check? (Eppadi Check Pannanum?)

Run these commands in your terminal (PowerShell or CMD):

```bash
java -version    # Must show 17.x or 21.x
mvn -version     # Must show Apache Maven 3.8+
```

---

## 3️⃣ How to Install if Missing? (Windows)

Open PowerShell and run:

```powershell
# 1. Install Java 17:
winget install EclipseAdoptium.Temurin.17.JDK

# 2. Install Maven:
winget install Apache.Maven
```

> **Note**: After installing, restart your terminal so the new paths take effect.

---

## 🚀 Quick Run Guide (All 10 Programs)

> **Important**: All web apps use port **8080**. Run only **one program at a time**. Press `Ctrl + C` to stop.

| # | Folder | Run Command | URL / What to test |
|---|--------|-------------|-------------------|
| **1** | `login-app` | `mvn jetty:run` | **http://localhost:8080/login-app/login.jsp** (`admin` / `admin123`) |
| **2** | `hibernate-jpa-app` | `mvn compile`<br>`mvn org.codehaus.mojo:exec-maven-plugin:3.2.0:java "-Dexec.mainClass=com.lab.Main"` | Interactive CRUD console menu (0 to 11) |
| **3** | `spring-mvc-app` | `mvn spring-boot:run` | **http://localhost:8080/employees** |
| **4** | `spring-data-jpa-app` | `mvn spring-boot:run` | **http://localhost:8080/employees**<br>H2 DB: **http://localhost:8080/h2-console** |
| **5** | `rest-api-app` | `mvn spring-boot:run` | **http://localhost:8080/api/products** |
| **6** | `spring-security-app` | `mvn spring-boot:run` | **http://localhost:8080/** (`admin`/`admin123`, `user`/`user123`) |
| **7** | `validation-exception-app` | `mvn spring-boot:run` | **http://localhost:8080/api/products** (Validation error JSON) |
| **8** | `logging-monitoring-app` | `mvn spring-boot:run` | Actuator: **http://localhost:8080/actuator/health**<br>Logs in `logs/` folder |
| **9** | `testing-app` | `mvn test` | Runs all 29 automated tests |
| **10** | `deployment-app` | `mvn clean package -DskipTests`<br>`java -jar target/deployment-app.jar --spring.profiles.active=dev` | Health: **http://localhost:8080/actuator/health** |

*(Each folder also has its own individual `README.md` with more details).*
