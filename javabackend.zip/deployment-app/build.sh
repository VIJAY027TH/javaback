#!/bin/bash
# Build the project
echo "Building project..."
mvn clean package -DskipTests

# Check if build succeeded
if [ $? -eq 0 ]; then
    echo "Build successful! JAR created at: target/deployment-app.jar"
    echo ""
    echo "To run in DEV mode:"
    echo "  java -jar target/deployment-app.jar --spring.profiles.active=dev"
    echo ""
    echo "To run in PROD mode:"
    echo "  java -jar target/deployment-app.jar --spring.profiles.active=prod"
    echo ""
    echo "Or using deploy script:"
    echo "  export DB_PASSWORD=yourpassword"
    echo "  ./src/main/resources/scripts/deploy.sh start"
    echo ""
    echo "Or using Docker:"
    echo "  docker build -t deployment-app ."
    echo "  docker run -p 8080:8080 deployment-app"
else
    echo "Build failed!"
    exit 1
fi
