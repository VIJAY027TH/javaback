@echo off
echo Building deployment-app...
mvn clean package -DskipTests
if %ERRORLEVEL% EQU 0 (
    echo.
    echo ========================================================
    echo Build successful! JAR created at: target\deployment-app.jar
    echo ========================================================
    echo.
    echo To run in DEV mode (H2 In-Memory DB):
    echo   java -jar target\deployment-app.jar --spring.profiles.active=dev
    echo.
    echo To run in PROD mode (MySQL):
    echo   set DB_PASSWORD=yourpassword
    echo   java -jar target\deployment-app.jar --spring.profiles.active=prod --logging.file.name=logs/app.log
) else (
    echo Build failed!
)
