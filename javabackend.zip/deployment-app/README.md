# 10. Deployment App (Profiles & Packaging)

Demonstrates Spring Boot environment profiles (dev & prod).

## 🚀 How to Run on Windows (Dev Mode — H2 Database)
```bash
mvn clean package -DskipTests
java -jar target/deployment-app.jar --spring.profiles.active=dev
```
*(Or simply run `.\build.bat`)*

## 🌐 How to Test
- **API**: **http://localhost:8080/api/products**
- **Health Check**: **http://localhost:8080/actuator/health**

## 🛑 How to Stop
Press `Ctrl + C`
