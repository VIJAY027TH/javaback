#!/bin/bash
APP_NAME=deployment-app
JAR_FILE=target/$APP_NAME.jar
LOG_DIR=/var/log/$APP_NAME
PID_FILE=/tmp/$APP_NAME.pid

case "$1" in
  start)
    echo "Starting $APP_NAME..."
    mkdir -p $LOG_DIR
    nohup java -jar $JAR_FILE --spring.profiles.active=prod > $LOG_DIR/startup.log 2>&1 &
    echo $! > $PID_FILE
    echo "$APP_NAME started (PID: $(cat $PID_FILE))"
    ;;
  stop)
    if [ -f $PID_FILE ]; then
      PID=$(cat $PID_FILE)
      echo "Stopping $APP_NAME (PID: $PID)..."
      kill $PID
      rm -f $PID_FILE
      echo "$APP_NAME stopped"
    else
      echo "$APP_NAME is not running"
    fi
    ;;
  status)
    if [ -f $PID_FILE ] && kill -0 $(cat $PID_FILE) 2>/dev/null; then
      echo "$APP_NAME is running (PID: $(cat $PID_FILE))"
    else
      echo "$APP_NAME is not running"
    fi
    ;;
  restart)
    $0 stop
    sleep 2
    $0 start
    ;;
  *)
    echo "Usage: $0 {start|stop|status|restart}"
    exit 1
    ;;
esac
