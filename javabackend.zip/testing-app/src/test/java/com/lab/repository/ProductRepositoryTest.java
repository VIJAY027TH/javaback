package com.lab.repository;

import com.lab.entity.Product;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class ProductRepositoryTest {

    @Autowired
    private ProductRepository productRepository;

    @Test
    void save_ShouldPersistProduct() {
        Product product = new Product("Laptop", "Electronics", 999.99, 50);

        Product saved = productRepository.save(product);

        assertNotNull(saved.getId());
        assertEquals("Laptop", saved.getName());
    }

    @Test
    void findById_WhenExists_ShouldReturnProduct() {
        Product product = productRepository.save(new Product("Laptop", "Electronics", 999.99, 50));

        Optional<Product> found = productRepository.findById(product.getId());

        assertTrue(found.isPresent());
        assertEquals("Laptop", found.get().getName());
    }

    @Test
    void findById_WhenNotExists_ShouldReturnEmpty() {
        Optional<Product> found = productRepository.findById(99L);

        assertFalse(found.isPresent());
    }

    @Test
    void findAll_ShouldReturnAllProducts() {
        productRepository.save(new Product("Laptop", "Electronics", 999.99, 50));
        productRepository.save(new Product("Phone", "Electronics", 599.99, 100));

        List<Product> products = productRepository.findAll();

        assertEquals(2, products.size());
    }

    @Test
    void findByCategory_ShouldReturnFilteredProducts() {
        productRepository.save(new Product("Laptop", "Electronics", 999.99, 50));
        productRepository.save(new Product("Phone", "Electronics", 599.99, 100));
        productRepository.save(new Product("Shirt", "Clothing", 29.99, 200));

        List<Product> electronics = productRepository.findByCategory("Electronics");

        assertEquals(2, electronics.size());
    }

    @Test
    void deleteById_ShouldRemoveProduct() {
        Product product = productRepository.save(new Product("Laptop", "Electronics", 999.99, 50));

        productRepository.deleteById(product.getId());

        assertFalse(productRepository.findById(product.getId()).isPresent());
    }

    @Test
    void existsById_WhenExists_ShouldReturnTrue() {
        Product product = productRepository.save(new Product("Laptop", "Electronics", 999.99, 50));

        boolean exists = productRepository.existsById(product.getId());

        assertTrue(exists);
    }
}
