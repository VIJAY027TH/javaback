package com.lab;

import com.lab.entity.Product;
import com.lab.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class ProductIntegrationTest {

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private ProductRepository productRepository;

    @BeforeEach
    void setUp() {
        productRepository.deleteAll();
    }

    @Test
    void createAndRetrieveProduct_ShouldWorkEndToEnd() {
        Product product = new Product("Laptop", "Electronics", 999.99, 50);

        ResponseEntity<Product> createResponse = restTemplate.postForEntity(
                "/api/products", product, Product.class);

        assertEquals(HttpStatus.CREATED, createResponse.getStatusCode());
        assertNotNull(createResponse.getBody().getId());
        assertEquals("Laptop", createResponse.getBody().getName());

        Long id = createResponse.getBody().getId();

        ResponseEntity<Product> getResponse = restTemplate.getForEntity(
                "/api/products/" + id, Product.class);

        assertEquals(HttpStatus.OK, getResponse.getStatusCode());
        assertEquals("Laptop", getResponse.getBody().getName());
    }

    @Test
    void getAllProducts_ShouldReturnAll() {
        restTemplate.postForEntity("/api/products", new Product("Laptop", "Electronics", 999.99, 50), Product.class);
        restTemplate.postForEntity("/api/products", new Product("Phone", "Electronics", 599.99, 100), Product.class);

        ResponseEntity<Product[]> response = restTemplate.getForEntity("/api/products", Product[].class);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(2, response.getBody().length);
    }

    @Test
    void getProductById_WhenNotExists_ShouldReturn404() {
        ResponseEntity<Product> response = restTemplate.getForEntity("/api/products/999", Product.class);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
    }

    @Test
    void deleteProduct_ShouldRemoveIt() {
        ResponseEntity<Product> createResponse = restTemplate.postForEntity(
                "/api/products", new Product("Laptop", "Electronics", 999.99, 50), Product.class);
        Long id = createResponse.getBody().getId();

        restTemplate.delete("/api/products/" + id);

        ResponseEntity<Product> getResponse = restTemplate.getForEntity("/api/products/" + id, Product.class);
        assertEquals(HttpStatus.NOT_FOUND, getResponse.getStatusCode());
    }
}
