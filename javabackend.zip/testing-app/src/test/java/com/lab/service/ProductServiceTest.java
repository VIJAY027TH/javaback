package com.lab.service;

import com.lab.entity.Product;
import com.lab.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    private ProductService productService;

    @BeforeEach
    void setUp() {
        productService = new ProductService(productRepository);
    }

    @Test
    void getAllProducts_ShouldReturnAllProducts() {
        List<Product> mockProducts = List.of(
                new Product("Laptop", "Electronics", 999.99, 50),
                new Product("Phone", "Electronics", 599.99, 100)
        );
        when(productRepository.findAll()).thenReturn(mockProducts);

        List<Product> result = productService.getAllProducts();

        assertEquals(2, result.size());
        verify(productRepository, times(1)).findAll();
    }

    @Test
    void getProductById_WhenExists_ShouldReturnProduct() {
        Product product = new Product("Laptop", "Electronics", 999.99, 50);
        product.setId(1L);
        when(productRepository.findById(1L)).thenReturn(Optional.of(product));

        Optional<Product> result = productService.getProductById(1L);

        assertTrue(result.isPresent());
        assertEquals("Laptop", result.get().getName());
    }

    @Test
    void getProductById_WhenNotExists_ShouldReturnEmpty() {
        when(productRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Product> result = productService.getProductById(99L);

        assertFalse(result.isPresent());
    }

    @Test
    void createProduct_ShouldSaveAndReturnProduct() {
        Product product = new Product("Laptop", "Electronics", 999.99, 50);
        Product savedProduct = new Product("Laptop", "Electronics", 999.99, 50);
        savedProduct.setId(1L);
        when(productRepository.save(any(Product.class))).thenReturn(savedProduct);

        Product result = productService.createProduct(product);

        assertNotNull(result.getId());
        assertEquals("Laptop", result.getName());
        verify(productRepository, times(1)).save(product);
    }

    @Test
    void createProduct_WithNonPositivePrice_ShouldThrowException() {
        Product product = new Product("Laptop", "Electronics", -10, 50);

        assertThrows(IllegalArgumentException.class, () -> productService.createProduct(product));
        verify(productRepository, never()).save(any());
    }

    @Test
    void updateProduct_WhenExists_ShouldUpdateAndReturn() {
        Product existing = new Product("Laptop", "Electronics", 999.99, 50);
        existing.setId(1L);
        Product updated = new Product("Gaming Laptop", "Computers", 1299.99, 30);

        when(productRepository.findById(1L)).thenReturn(Optional.of(existing));
        when(productRepository.save(any(Product.class))).thenAnswer(invocation -> invocation.getArgument(0));

        Optional<Product> result = productService.updateProduct(1L, updated);

        assertTrue(result.isPresent());
        assertEquals("Gaming Laptop", result.get().getName());
        assertEquals("Computers", result.get().getCategory());
        assertEquals(1299.99, result.get().getPrice());
        assertEquals(30, result.get().getStock());
    }

    @Test
    void updateProduct_WhenNotExists_ShouldReturnEmpty() {
        when(productRepository.findById(99L)).thenReturn(Optional.empty());

        Optional<Product> result = productService.updateProduct(99L, new Product());

        assertFalse(result.isPresent());
        verify(productRepository, never()).save(any());
    }

    @Test
    void deleteProduct_WhenExists_ShouldReturnTrue() {
        when(productRepository.existsById(1L)).thenReturn(true);

        boolean result = productService.deleteProduct(1L);

        assertTrue(result);
        verify(productRepository, times(1)).deleteById(1L);
    }

    @Test
    void deleteProduct_WhenNotExists_ShouldReturnFalse() {
        when(productRepository.existsById(99L)).thenReturn(false);

        boolean result = productService.deleteProduct(99L);

        assertFalse(result);
        verify(productRepository, never()).deleteById(any());
    }
}
