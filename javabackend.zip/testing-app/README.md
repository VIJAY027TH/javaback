# 9. Testing App (JUnit 5 + Mockito)

29 automated unit, repository, controller, and integration tests.

## 🧪 How to Run Tests
```bash
mvn test
```
👉 Expected Result: **`BUILD SUCCESS`** with all 29 tests passing!

## 🚀 How to Run the App Normally
```bash
mvn spring-boot:run
```
- Open: **http://localhost:8080/api/products**
- Stop: `Ctrl + C`
