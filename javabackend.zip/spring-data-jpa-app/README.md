# 4. Spring Data JPA App (H2 + Thymeleaf)

Employee CRUD using Spring Data JPA with an embedded H2 database.

## 🚀 How to Run
```bash
mvn spring-boot:run
```

## 🌐 How to Test
- **Web App**: **http://localhost:8080/employees**
- **H2 Database Console**: **http://localhost:8080/h2-console**
  - JDBC URL: `jdbc:h2:mem:labdb`
  - User: `sa`
  - Password: *(leave blank)*

## 🛑 How to Stop
Press `Ctrl + C`
