package com.lab.service;

import com.lab.entity.Product;
import com.lab.repository.ProductRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ProductService {

    private static final Logger log = LoggerFactory.getLogger(ProductService.class);

    private final ProductRepository productRepository;

    public ProductService(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public List<Product> getAllProducts() {
        log.debug("Fetching all products");
        List<Product> products = productRepository.findAll();
        log.info("Retrieved {} products from database", products.size());
        return products;
    }

    public Optional<Product> getProductById(Long id) {
        log.debug("Fetching product with id: {}", id);
        Optional<Product> product = productRepository.findById(id);
        if (product.isPresent()) {
            log.info("Product found: {}", product.get().getName());
        } else {
            log.warn("Product not found with id: {}", id);
        }
        return product;
    }

    public Product createProduct(Product product) {
        log.info("Creating product: {} in category {}", product.getName(), product.getCategory());
        Product saved = productRepository.save(product);
        log.debug("Product created with id: {}", saved.getId());
        return saved;
    }

    public Optional<Product> updateProduct(Long id, Product updated) {
        log.debug("Updating product with id: {}", id);
        return productRepository.findById(id)
                .map(product -> {
                    product.setName(updated.getName());
                    product.setCategory(updated.getCategory());
                    product.setPrice(updated.getPrice());
                    product.setStock(updated.getStock());
                    Product saved = productRepository.save(product);
                    log.info("Product updated: {} (id={})", saved.getName(), saved.getId());
                    return saved;
                });
    }

    public boolean deleteProduct(Long id) {
        log.debug("Deleting product with id: {}", id);
        if (productRepository.existsById(id)) {
            productRepository.deleteById(id);
            log.info("Product deleted with id: {}", id);
            return true;
        } else {
            log.warn("Attempted to delete non-existent product with id: {}", id);
            return false;
        }
    }
}
