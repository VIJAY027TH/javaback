# 8. Logging & Monitoring App (Logback + Actuator)

Structured file logging (`logs/`) with Spring Boot Actuator health and metrics monitoring.

## 🚀 How to Run
```bash
mvn spring-boot:run
```

## 🌐 How to Test
- **Health Check**: **http://localhost:8080/actuator/health**
- **Metrics**: **http://localhost:8080/actuator/metrics**
- **Log Files**: Automatically written to `logs/logging-monitoring-app.log` in this folder.

## 🛑 How to Stop
Press `Ctrl + C`
