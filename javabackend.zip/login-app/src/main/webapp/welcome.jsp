<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>
<body>
    <%
        String username = (String) session.getAttribute("username");
        if (username == null) {
            response.sendRedirect("login.jsp");
        } else {
            out.println("<h2>Welcome, " + username + "!</h2>");
        }
    %>
    <br>
    <a href="logout.jsp">Logout</a>
</body>
</html>
