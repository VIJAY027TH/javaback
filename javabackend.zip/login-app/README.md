# 1. Login App (Servlet + JSP)

Plain Jakarta Servlet + JSP login using embedded Jetty.

## 🚀 How to Run
```bash
mvn jetty:run
```

## 🌐 How to Test
- Open: **http://localhost:8080/login-app/login.jsp**
- **Username**: `admin`
- **Password**: `admin123`

## 🛑 How to Stop
Press `Ctrl + C`
