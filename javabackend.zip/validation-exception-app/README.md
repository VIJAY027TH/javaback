# 7. Validation & Exception Handling App

Bean validation (`@Valid`) with global exception handling returning structured JSON errors instead of stack traces.

## 🚀 How to Run
```bash
mvn spring-boot:run
```

## 🧪 How to Test (PowerShell)
Send an invalid product (blank name & negative price):
```powershell
Invoke-RestMethod -Uri "http://localhost:8080/api/products" -Method Post -ContentType "application/json" -Body '{"name":"","category":"","price":-10}'
```
👉 Returns clean **HTTP 400 Bad Request** JSON with exact validation errors.

## 🛑 How to Stop
Press `Ctrl + C`
