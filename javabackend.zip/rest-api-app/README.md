# 5. REST API App (JSON Products API)

RESTful CRUD API for products returning JSON.

## 🚀 How to Run
```bash
mvn spring-boot:run
```

## 🌐 API Endpoints (Base: http://localhost:8080/api/products)
- **GET** `/api/products` — View all products in browser
- **POST** `/api/products` — Add product (JSON body: `{"name":"Pen","category":"Stationery","price":10.5}`)
- **GET** `/api/products/1` — Get product with ID 1
- **DELETE** `/api/products/1` — Delete product

## 🛑 How to Stop
Press `Ctrl + C`
